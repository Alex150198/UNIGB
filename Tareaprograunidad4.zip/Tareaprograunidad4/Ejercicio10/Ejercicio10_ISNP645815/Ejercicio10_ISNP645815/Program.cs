﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int totalStudents = 15;
        int sumAges = 0;

        for (int i = 1; i <= totalStudents; i++)
        {
            Console.Write($"Ingrese la edad del estudiante {i}: ");
            string input = Console.ReadLine();
            int age;

            if (int.TryParse(input, out age) && age > 0)
            {
                sumAges += age;
            }
            else
            {
                Console.WriteLine("ERROR: Por favor, ingrese una edad válida.");
                i--; // Decrementamos el contador para repetir la iteración actual.
            }
        }

        double averageAge = (double)sumAges / totalStudents;
        Console.WriteLine($"La edad promedio de los {totalStudents} estudiantes es: {averageAge}");
    }
}