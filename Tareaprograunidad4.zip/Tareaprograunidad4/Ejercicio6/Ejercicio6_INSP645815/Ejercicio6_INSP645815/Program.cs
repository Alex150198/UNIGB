﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double sum = 0;

        Console.WriteLine("Ingrese 5 números:");

        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Número {i + 1}: ");
            double number = Convert.ToDouble(Console.ReadLine());
            sum += number;
        }

        double average = sum / 5;
        Console.WriteLine($"El promedio de los 5 números es: {average}");
    }
}