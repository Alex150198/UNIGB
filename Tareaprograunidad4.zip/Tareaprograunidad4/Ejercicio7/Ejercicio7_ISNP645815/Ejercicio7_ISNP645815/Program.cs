﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double number;
        bool validInput = false;

        do
        {
            Console.Write("Ingrese un número mayor que cero: ");
            string input = Console.ReadLine();

            if (double.TryParse(input, out number) && number > 0)
            {
                validInput = true;
            }
            else
            {
                Console.WriteLine("ERROR. Reingresar número.");
            }

        } while (!validInput);

        double square = Math.Pow(number, 2);
        Console.WriteLine($"El cuadrado de {number} es: {square}");
    }
}
