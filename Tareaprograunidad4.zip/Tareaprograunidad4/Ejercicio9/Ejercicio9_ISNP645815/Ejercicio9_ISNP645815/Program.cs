﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int number;

        Console.Write("Ingrese un número: ");
        string input = Console.ReadLine();

        if (int.TryParse(input, out number))
        {
            if (number % 2 == 0)
            {
                Console.WriteLine($"El número {number} es par.");
            }
            else
            {
                Console.WriteLine($"El número {number} es impar.");
            }
        }
        else
        {
            Console.WriteLine("ERROR: No se ha ingresado un número válido.");
        }
    }
}