﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double number;

        Console.Write("Ingrese un número: ");
        string input = Console.ReadLine();

        if (double.TryParse(input, out number))
        {
            if (number > 0)
            {
                Console.WriteLine("El número ingresado es positivo.");
            }
            else if (number < 0)
            {
                Console.WriteLine("El número ingresado es negativo.");
            }
            else
            {
                Console.WriteLine("El número ingresado es cero.");
            }
        }
        else
        {
            Console.WriteLine("ERROR: No se ha ingresado un número válido.");
        }
    }
}